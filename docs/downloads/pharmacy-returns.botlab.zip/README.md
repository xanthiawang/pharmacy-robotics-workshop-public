Return desk - lift, hold and replace

Marvin M6S + supplied Handle-L1 right_handv5. 7 arm + 6 active hand controls; 5 passive joints follow curves digitized from the supplier manual. Meshes and CAD inertias preserved. Torque, contact and mounting settings are authored simulation settings, not hardware calibration.
